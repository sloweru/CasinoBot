﻿#Трогать, значения можно менять
admin = [] #ID админа
support_name = '' #Имя саппорта, будет выводиться при нажатии кнопки "поддержка"
token = "" #Токен бота
client_id = '' #client_id, получается при создании приложения Юмани
number_qiwi = '' #Номер вашего QIWI кошелька
token_qiwi = '' #Токен киви
token_youmoney = ''  # Токен ЮМани
p2p_closed_token =''  #Приватный ключ P2P QIWI
open_coinbase = '' #Публичный ключ CoinBase
close_coinbase = '' #Секретный токен CoinBase
secret_crystal = ''  #Секретный ключ кассы CrystalPay
login_crystal = ''  # Логин кассы CrystalPay

#Не трогать, значения должны быть по умолчанию
balance = 0
referals_ = 0
bill_id =  None
photo_id = None
text = None
auto_output = 0
amount = None
bet = 0
game = None
referal_level = 1
referer = None
referal_profit = 0
ban = 0
cash = 0
method = None
voucher = None
promo = None
winning = 0
demobalance = 0



